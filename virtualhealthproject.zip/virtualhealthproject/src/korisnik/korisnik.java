package korisnik;

import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import klase.*;
import sample.login;

import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class korisnik implements Initializable {

    public Label info1,info2;
    public Label info3;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        pacijent p = login.p;
        info1.setText(
                        "korisnicke informacije\n"+
                        "id: "+p.getId()+"\n"+
                        "ime: "+p.getIme()+"\n"+
                        "prezime: "+p.getPrezime()+"\n"+
                        "korime: "+p.getKorime()+"\n"+
                        "lozinka: "+p.getLozinka()
        );

        Connection conn = new konekcija().vratiKonekciju();


        karton k = karton.vratiKarton(p.getId());
        if(k!=null){
            info2.setText("sifra kartona: "+k.getSifra());
            lekar l = lekar.vratiLekara(k.getId_lekara());
            info3.setText(
                            "id: "+l.getId()+"\n"+
                            "ime: "+l.getIme()+"\n"+
                            "prezime: "+l.getPrezime()
            );
            ArrayList<pregled> niz = pregled.vratiPreglede(k.getId());
            String s = "pregledi\n";
            for(int i=0;i<niz.size();i++){
                s+=niz.get(i).getDatum()+"\n";
                System.out.println(niz.get(i).getDatum());
            }
            info3.setText(s);

        }else{
            info2.setText("nema otvorenog kartona");
        }


    }
}
