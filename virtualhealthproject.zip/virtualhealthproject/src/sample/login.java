package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import javafx.stage.Stage;
import javafx.stage.StageStyle;

import klase.*;

public class login implements Initializable {
    public static admin a;
    public static pacijent p;

    @FXML
    public javafx.scene.control.TextField korime;

    @FXML
    public javafx.scene.control.TextField lozinka;

    @FXML
    public javafx.scene.control.CheckBox admin;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    private void loadWindow(String location,String title) throws IOException {
        Parent root = FXMLLoader.load((getClass().getResource(location)));
        Scene sc = new Scene(root);
        Stage st = new Stage(StageStyle.DECORATED);
        st.setScene(sc);
        st.setTitle(title);
        st.show();
    }

    public void logovanje(javafx.event.ActionEvent actionEvent) {
        String korimeText = korime.getText();
        String lozinkaText = lozinka.getText();

        if(korimeText.isEmpty() || lozinkaText.isEmpty()){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText(null);
            alert.setContentText("uneti sve podatke");
            alert.showAndWait();
            return;
        }

        Connection conn = new konekcija().vratiKonekciju();

        try {
            Statement stmt = conn.createStatement();

            if(admin.isSelected()){
                //admin
                String sql = "SELECT * FROM admin WHERE korime='"+korimeText+"' AND lozinka='"+lozinkaText+"'";
                ResultSet rs = stmt.executeQuery(sql);

                if(rs.next()){
                    //uspesno logovanje
                    //admin(int id, String ime, String prezime, String korime, String lozinka)
                    admin ad = new admin(
                            rs.getInt("id"),
                            rs.getString("ime"),
                            rs.getString("prezime"),
                            rs.getString("korime"),
                            rs.getString("lozinka")
                    );
                    a=ad;
                    ((Node)actionEvent.getSource()).getScene().getWindow().hide();
                    try {
                        loadWindow("/admin/administrator.fxml","ulogovani ste");
                    } catch (IOException e) {
                        System.out.println(e);
                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("neispravni podaci");
                    alert.showAndWait();
                    return;
                }

            }else{
                //korisnik
                String sql = "SELECT * FROM pacijent WHERE korime='"+korimeText+"' AND lozinka='"+lozinkaText+"'";
                ResultSet rs = stmt.executeQuery(sql);

                if(rs.next()){
                    //uspesno logovanje
                    pacijent pc = new pacijent(
                            rs.getInt("id"),
                            rs.getString("ime"),
                            rs.getString("prezime"),
                            rs.getString("korime"),
                            rs.getString("lozinka")
                    );
                    p=pc;
                    ((Node)actionEvent.getSource()).getScene().getWindow().hide();
                    try {
                        loadWindow("/korisnik/korisnik.fxml","ulogovani ste");
                    } catch (IOException e) {
                        System.out.println(e);
                    }
                }else{
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText(null);
                    alert.setContentText("neispravni podaci");
                    alert.showAndWait();
                    return;
                }
            }



            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
