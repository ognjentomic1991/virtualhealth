package klase;

import klase.konekcija;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class admin {
    private int id;
    private String ime,prezime,korime,lozinka;

    public admin(int id, String ime, String prezime, String korime, String lozinka) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.korime = korime;
        this.lozinka = lozinka;
    }

    public admin(String ime, String prezime, String korime, String lozinka) {
        this.ime = ime;
        this.prezime = prezime;
        this.korime = korime;
        this.lozinka = lozinka;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getKorime() {
        return korime;
    }

    public void setKorime(String korime) {
        this.korime = korime;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public boolean upisi(){
        konekcija k = new konekcija();
        Connection conn = k.vratiKonekciju();

        Statement stmt = null;

        try {
            stmt = conn.createStatement();
            String sql = "INSERT INTO admin VALUES(null,'"+this.ime+"','"+this.prezime+"','"+this.korime+"','"+this.lozinka+"')";
            stmt.executeUpdate(sql);
            conn.close();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }
    }

    @Override
    public String toString() {
        return "admin{" +
                "id=" + id +
                ", ime='" + ime + '\'' +
                ", prezime='" + prezime + '\'' +
                ", korime='" + korime + '\'' +
                ", lozinka='" + lozinka + '\'' +
                '}';
    }
}
