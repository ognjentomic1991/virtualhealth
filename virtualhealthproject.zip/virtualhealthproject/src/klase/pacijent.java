package klase;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class pacijent {
    private int id;
    private String ime,prezime,korime,lozinka;

    public pacijent(int id, String ime, String prezime, String korime, String lozinka) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.korime = korime;
        this.lozinka = lozinka;
    }

    public pacijent(String ime, String prezime, String korime, String lozinka) {
        this.ime = ime;
        this.prezime = prezime;
        this.korime = korime;
        this.lozinka = lozinka;
    }


    public void obrisi(){
        Connection conn = new konekcija().vratiKonekciju();

        try {
            Statement stmt = conn.createStatement();
            String sql = "DELETE FROM pacijent WHERE id="+this.id;
            stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static int prebrojPacijente(){
        Connection conn = new konekcija().vratiKonekciju();
        String sql = "SELECT COUNT(*) AS broj FROM pacijent";
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            int br = rs.getInt("broj");
            conn.close();
            return br;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return 0;
        }
    }

    public static pacijent[] vratiSvePacijente(){
        pacijent[] lista = new pacijent[prebrojPacijente()];

        Connection conn = new konekcija().vratiKonekciju();
        String sql = "SELECT * FROM pacijent";
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            int i=0;
            while(rs.next()){
                lista[i] = new pacijent(
                        rs.getInt("id"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("korime"),
                        rs.getString("lozinka")
                );
                i++;
            }
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return lista;
    }

    public boolean upisi(){
        konekcija k = new konekcija();
        Connection conn = k.vratiKonekciju();

        Statement stmt = null;

        try {
            stmt = conn.createStatement();
            String sql = "INSERT INTO pacijent VALUES(null,'"+this.ime+"','"+this.prezime+"','"+this.korime+"','"+this.lozinka+"')";
            stmt.executeUpdate(sql);
            conn.close();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getKorime() {
        return korime;
    }

    public void setKorime(String korime) {
        this.korime = korime;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    @Override
    public String toString() {
        return "pacijent{" +
                "id=" + id +
                ", ime='" + ime + '\'' +
                ", prezime='" + prezime + '\'' +
                ", korime='" + korime + '\'' +
                ", lozinka='" + lozinka + '\'' +
                '}';
    }
}

