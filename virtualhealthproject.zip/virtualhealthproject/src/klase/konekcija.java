package klase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class konekcija {
    private String driver ;
    private String url;
    private String korime;
    private String lozinka;

    public konekcija(){
        this.driver="com.mysql.jdbc.Driver";
        this.url="jdbc:mysql://localhost/virtualhealth";
        this.korime="root";
        this.lozinka="";
    }

    public Connection vratiKonekciju(){
        Connection conn = null;
        try {
            Class.forName(this.driver);
            conn = DriverManager.getConnection(this.url, this.korime, this.lozinka);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }
}
