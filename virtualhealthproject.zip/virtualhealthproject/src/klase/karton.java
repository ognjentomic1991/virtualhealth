package klase;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class karton {
    private int id,id_pacijenta,id_lekara;
    private String sifra;

    public karton(int id, int id_pacijenta, int id_lekara, String sifra) {
        this.id = id;
        this.id_pacijenta = id_pacijenta;
        this.id_lekara = id_lekara;
        this.sifra = sifra;
    }

    public karton(int id_pacijenta, int id_lekara, String sifra) {
        this.id_pacijenta = id_pacijenta;
        this.id_lekara = id_lekara;
        this.sifra = sifra;
    }

    public static karton vratiKarton(int id){
        Connection conn = new konekcija().vratiKonekciju();
        String sql = "SELECT * FROM karton WHERE id_pacijenta="+id;
        Statement stmt = null;
        karton k = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if(rs.next()){
                k = new karton(
                        rs.getInt("id"),
                        rs.getInt("id_pacijenta"),
                        rs.getInt("id_lekara"),
                        rs.getString("sifra")
                );
            }

            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return k;
    }

    public boolean upisi(){
        konekcija k = new konekcija();
        Connection conn = k.vratiKonekciju();

        Statement stmt = null;

        try {
            stmt = conn.createStatement();
            String sql = "INSERT INTO karton VALUES(null,"+this.id_pacijenta+","+this.id_lekara+",'"+this.sifra+"')";
            stmt.executeUpdate(sql);
            conn.close();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_pacijenta() {
        return id_pacijenta;
    }

    public void setId_pacijenta(int id_pacijenta) {
        this.id_pacijenta = id_pacijenta;
    }

    public int getId_lekara() {
        return id_lekara;
    }

    public void setId_lekara(int id_lekara) {
        this.id_lekara = id_lekara;
    }

    public String getSifra() {
        return sifra;
    }

    public void setSifra(String sifra) {
        this.sifra = sifra;
    }

    @Override
    public String toString() {
        return "karton{" +
                "id=" + id +
                ", id_pacijenta=" + id_pacijenta +
                ", id_lekara=" + id_lekara +
                ", sifra='" + sifra + '\'' +
                '}';
    }
}
