package klase;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class lekar {
    private int id;
    private String ime,prezime,specijalnost;

    public lekar(int id, String ime, String prezime, String specijalnost) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.specijalnost = specijalnost;
    }

    public lekar(String ime, String prezime, String specijalnost) {
        this.ime = ime;
        this.prezime = prezime;
        this.specijalnost = specijalnost;
    }

    public void obrisi(){
        Connection conn = new konekcija().vratiKonekciju();

        try {
            Statement stmt = conn.createStatement();
            String sql = "DELETE FROM lekar WHERE id="+this.id;
            stmt.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static lekar vratiLekara(int id){
        Connection conn = new konekcija().vratiKonekciju();
        String sql = "SELECT * FROM lekar WHERE id="+id;
        Statement stmt = null;
        lekar k = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if(rs.next()){
                k = new lekar(
                        rs.getInt("id"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("specijalnost")
                );
            }

            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return k;
    }

    public static int prebrojLekare(){
        Connection conn = new konekcija().vratiKonekciju();
        String sql = "SELECT COUNT(*) AS broj FROM lekar";
        try {
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            int br = rs.getInt("broj");
            conn.close();
            return br;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return 0;
        }
    }

    public static lekar[] vratiSveLekare(){
        lekar[] lista = new lekar[prebrojLekare()];

        Connection conn = new konekcija().vratiKonekciju();
        String sql = "SELECT * FROM lekar";
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            int i=0;
            while(rs.next()){
                lista[i] = new lekar(
                        rs.getInt("id"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("specijalnost")
                );
                i++;
            }
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return lista;
    }

    public boolean upisi(){
        konekcija k = new konekcija();
        Connection conn = k.vratiKonekciju();

        Statement stmt = null;

        try {
            stmt = conn.createStatement();
            String sql = "INSERT INTO lekar VALUES(null,'"+this.ime+"','"+this.prezime+"','"+this.specijalnost+"')";
            stmt.executeUpdate(sql);
            conn.close();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return false;
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getSpecijalnost() {
        return specijalnost;
    }

    public void setSpecijalnost(String specijalnost) {
        this.specijalnost = specijalnost;
    }

    @Override
    public String toString() {
        return "lekar{" +
                "id=" + id +
                ", ime='" + ime + '\'' +
                ", prezime='" + prezime + '\'' +
                ", specijalnost='" + specijalnost + '\'' +
                '}';
    }
}
