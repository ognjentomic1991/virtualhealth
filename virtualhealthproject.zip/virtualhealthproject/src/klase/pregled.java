package klase;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class pregled {
    private int id;
    private int id_kartona;
    private String datum;

    public pregled(int id, int id_kartona, String datum) {
        this.id = id;
        this.id_kartona = id_kartona;
        this.datum = datum;
    }

    public static ArrayList<pregled> vratiPreglede(int id){
        Connection conn = new konekcija().vratiKonekciju();
        String sql = "SELECT * FROM pregled WHERE id_kartona="+id;
        Statement stmt = null;
        ArrayList<pregled> niz = new ArrayList<pregled>();
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                niz.add(
                        new pregled(
                                rs.getInt("id"),
                                rs.getInt("id_kartona"),
                                rs.getString("datum")
                        )
                );
            }

            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return niz;
    }

    public pregled(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_kartona() {
        return id_kartona;
    }

    public void setId_kartona(int id_kartona) {
        this.id_kartona = id_kartona;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    @Override
    public String toString() {
        return "pregled{" +
                "id=" + id +
                ", id_kartona=" + id_kartona +
                ", datum='" + datum + '\'' +
                '}';
    }
}
