package admin;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import klase.*;

public class administrator implements Initializable {
    @FXML
    public javafx.scene.control.Label podaci;

    private void loadWindow(String location,String title) throws IOException {
        Parent root = FXMLLoader.load((getClass().getResource(location)));
        Scene sc = new Scene(root);
        Stage st = new Stage(StageStyle.DECORATED);
        st.setScene(sc);
        st.setTitle(title);
        st.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        admin a = sample.login.a;
        podaci.setText(
                "id: "+a.getId()+"\nime: "+a.getIme()+"\nprezime: "+a.getPrezime()+"\nkorime: "+a.getKorime()+"\nlozinka: "+a.getLozinka()
        );
    }


    public void dodavanjePacijenta(ActionEvent actionEvent) {
        System.out.println("dodavanje pacijenta");
        try {
            loadWindow("/admin/dodajPacijenta.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void prikazPacijenata(ActionEvent actionEvent) {
        System.out.println("dodavanje pacijenta");
        try {
            loadWindow("/admin/prikazPacijenata.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void dodajLekara(ActionEvent actionEvent) {
        try {
            loadWindow("/admin/dodajLekara.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void dodajAdmina(ActionEvent actionEvent) {
        try {
            loadWindow("/admin/dodajAdmina.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void otvaranjeKartona(ActionEvent actionEvent) {
        try {
            loadWindow("/admin/otvoriKarton.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void prikazLekara(ActionEvent actionEvent) {
        try {
            loadWindow("/admin/prikazLekara.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void obrisiLekara(ActionEvent actionEvent) {
        try {
            loadWindow("/admin/brisanjeLekara.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void obrisiPacijenta(ActionEvent actionEvent) {
        try {
            loadWindow("/admin/brisanjePacijenta.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void zakaziPregled(ActionEvent actionEvent) {
        try {
            loadWindow("/admin/zakaziPregled.fxml","ulogovani ste");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
