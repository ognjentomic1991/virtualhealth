package admin;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

import klase.*;

public class otvoriKarton implements Initializable {
    public ComboBox pacijent;
    public ComboBox lekar;
    public TextField sifra;
    public Button dodaj;
    //.getItems().add

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        pacijent[] pacijenti = klase.pacijent.vratiSvePacijente();
        lekar[] lekari = klase.lekar.vratiSveLekare();

        for(int i=0;i<pacijenti.length;i++){
            pacijent.getItems().add(pacijenti[i].getId()+"-"+pacijenti[i].getId());
        }

        for(int i=0;i<lekari.length;i++){
            lekar.getItems().add(lekari[i].getId()+"-"+lekari[i].getId());
        }
    }

    public void dodaj(ActionEvent actionEvent) {
        karton k = new karton(
                Integer.parseInt(((String) pacijent.getValue()).split("-")[0]),
                Integer.parseInt(((String) lekar.getValue()).split("-")[0]),
                sifra.getText()
        );
        k.upisi();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setContentText("karton otvoren");
        alert.showAndWait();
        ((Node)actionEvent.getSource()).getScene().getWindow().hide();
    }
}
