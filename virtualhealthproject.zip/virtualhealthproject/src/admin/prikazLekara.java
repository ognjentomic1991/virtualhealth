package admin;

import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import klase.pacijent;

import java.net.URL;
import java.util.ResourceBundle;

import klase.*;

public class prikazLekara implements Initializable {
    public ScrollPane prikaz;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String s="";
        lekar niz[] = klase.lekar.vratiSveLekare();
        for(int i=0;i<niz.length;i++){
            s+="id: "+niz[i].getId()+" ime: "+niz[i].getIme()+" prezime: "+niz[i].getPrezime()+" specijalnost: "+niz[i].getSpecijalnost()+"\n";
        }
        Label l =new Label(s);
        prikaz.setContent(l);
    }
}
