package admin;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;

import java.net.URL;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;

import klase.*;

public class zakaziPregled  implements Initializable {
    public ComboBox pacijenti;
    public DatePicker datum;
    public Button zakazi;

    public void zakazi(ActionEvent actionEvent) {
        String[] niz = ((String)pacijenti.getValue()).split("-");
        int id = Integer.parseInt(niz[0]);

        LocalDate localDate = datum.getValue();
        Instant instant = Instant.from(localDate.atStartOfDay(ZoneId.systemDefault()));
        Date date = Date.from(instant);

        String sql = "INSERT INTO pregled VALUES(null,(SELECT id FROM karton WHERE id_pacijenta="+id+"),'"+date+"')";
        Connection conn = new konekcija().vratiKonekciju();
        try {
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(sql);
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText(null);
            alert.setContentText("pregled zakazan");
            alert.showAndWait();
            ((Node)actionEvent.getSource()).getScene().getWindow().hide();
        } catch (SQLException throwables) {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText(null);
            alert.setContentText("greska proverite da li korisnik ima otvoren karton");
            alert.showAndWait();
            ((Node)actionEvent.getSource()).getScene().getWindow().hide();
        } catch (Exception e){

        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        pacijent niz[] = klase.pacijent.vratiSvePacijente();
        for(int i=0;i<niz.length;i++){
            pacijenti.getItems().add(niz[i].getId()+"-"+niz[i].getIme()+"-"+niz[i].getPrezime()+"-"+niz[i].getKorime()+"-"+niz[i].getLozinka());
        }
    }
}
