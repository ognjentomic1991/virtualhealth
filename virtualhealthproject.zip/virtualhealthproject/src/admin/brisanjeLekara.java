package admin;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;

import java.net.URL;
import java.util.ResourceBundle;

import klase.*;

public class brisanjeLekara  implements Initializable {
    //pacijent.getItems().add(pacijenti[i].getId()+"-"+pacijenti[i].getId());
    //Integer.parseInt(((String) pacijent.getValue()).split("-")[0])
    public ComboBox lekari;
    public Button obrisi;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        lekar niz[] = klase.lekar.vratiSveLekare();
        for(int i=0;i<niz.length;i++){
            lekari.getItems().add(niz[i].getId()+"-"+niz[i].getIme()+"-"+niz[i].getPrezime()+"-"+niz[i].getSpecijalnost());
        }
    }

    public void obrisi(ActionEvent actionEvent) {
        String[] niz = ((String)lekari.getValue()).split("-");
        lekar l = new lekar(
                Integer.parseInt(niz[0]),
                niz[1],
                niz[2],
                niz[3]
        );
        l.obrisi();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setContentText("lekar obrisan");
        alert.showAndWait();
        ((Node)actionEvent.getSource()).getScene().getWindow().hide();
    }
}
