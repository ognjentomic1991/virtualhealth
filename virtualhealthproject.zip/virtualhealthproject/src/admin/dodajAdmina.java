package admin;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import klase.pacijent;

import klase.*;

public class dodajAdmina {
    public Button dodaj;
    public TextField ime;
    public TextField prezime;
    public TextField korime;
    public TextField lozinka;

    public void dodaj(ActionEvent actionEvent) {
        String imeText = ime.getText();
        String prezimeText = prezime.getText();
        String korimeText = korime.getText();
        String lozinkaText = lozinka.getText();

        admin p = new admin(imeText,prezimeText,korimeText,lozinkaText);
        p.upisi();

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("administrator dodat");
        alert.showAndWait();
        ((Node)actionEvent.getSource()).getScene().getWindow().hide();
    }
}
