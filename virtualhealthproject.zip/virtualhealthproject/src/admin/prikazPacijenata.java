package admin;

import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollBar;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.scene.control.ScrollPane;
import klase.*;

import javax.swing.*;

public class prikazPacijenata implements Initializable {
    public ScrollPane prikaz;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        String s="";
        pacijent niz[] = klase.pacijent.vratiSvePacijente();
        for(int i=0;i<niz.length;i++){
            s+="id: "+niz[i].getId()+" ime: "+niz[i].getIme()+" prezime: "+niz[i].getPrezime()+" korisnicko ime: "+niz[i].getKorime()+"\n";
        }
        Label l =new Label(s);
        prikaz.setContent(l);
    }
}
