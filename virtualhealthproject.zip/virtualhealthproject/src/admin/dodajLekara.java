package admin;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;

import klase.*;

public class dodajLekara implements Initializable {
    public ComboBox specijalnost;
    public TextField prezime;
    public TextField ime;
    public Button dodaj;

    public void dodajLekara(ActionEvent actionEvent) {
        String textSpecijalnost = (String) specijalnost.getValue();
        String textPrezime = prezime.getText();
        String textIme = ime.getText();

        lekar l = new lekar(textIme,textPrezime,textSpecijalnost.split("-")[1]);
        l.upisi();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setContentText("lekar dodat");
        alert.showAndWait();
        ((Node)actionEvent.getSource()).getScene().getWindow().hide();

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Connection conn = new konekcija().vratiKonekciju();
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM specijalnosti";
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()){
                specijalnost.getItems().add(rs.getInt("id")+"-"+rs.getString("specijalnost"));
            }
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
