package admin;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import klase.lekar;

import java.net.URL;
import java.util.ResourceBundle;

import klase.*;

public class brisanjePacijenta   implements Initializable {
    //pacijent.getItems().add(pacijenti[i].getId()+"-"+pacijenti[i].getId());
    //Integer.parseInt(((String) pacijent.getValue()).split("-")[0])
    public ComboBox lekari;
    public Button obrisi;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        pacijent niz[] = klase.pacijent.vratiSvePacijente();
        for(int i=0;i<niz.length;i++){
            lekari.getItems().add(niz[i].getId()+"-"+niz[i].getIme()+"-"+niz[i].getPrezime()+"-"+niz[i].getKorime()+"-"+niz[i].getLozinka());
        }
    }

    public void obrisi(ActionEvent actionEvent) {
        String[] niz = ((String)lekari.getValue()).split("-");
        pacijent l = new pacijent(
                Integer.parseInt(niz[0]),
                niz[1],
                niz[2],
                niz[3],
                niz[4]
        );
        l.obrisi();
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText(null);
        alert.setContentText("pacijent obrisan");
        alert.showAndWait();
        ((Node)actionEvent.getSource()).getScene().getWindow().hide();
    }
}
