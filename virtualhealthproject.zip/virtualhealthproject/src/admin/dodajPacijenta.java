package admin;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.stage.Stage;
import javafx.stage.StageStyle;
import klase.*;

public class dodajPacijenta {

    public Button dodaj;
    public TextField ime;
    public TextField prezime;
    public TextField korime;
    public TextField lozinka;

    public void dodaj(ActionEvent actionEvent) {
        String imeText = ime.getText();
        String prezimeText = prezime.getText();
        String korimeText = korime.getText();
        String lozinkaText = lozinka.getText();

        pacijent p = new pacijent(imeText,prezimeText,korimeText,lozinkaText);
        p.upisi();

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setHeaderText(null);
        alert.setContentText("pacijent dodat");
        alert.showAndWait();
        ((Node)actionEvent.getSource()).getScene().getWindow().hide();
    }
}
